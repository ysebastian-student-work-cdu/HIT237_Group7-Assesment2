from django.shortcuts import render



# Create your views here.
def home(request):
    
    return render(request, 'AppOne/page1.html')

def item_list(request):

    return render(request, 'AppOne/page2.html')
 

def item_detail(request):

    return render(request, 'AppOne/item_detail.html')


def data_model(request):

    return render(request, 'AppOne/data_model')