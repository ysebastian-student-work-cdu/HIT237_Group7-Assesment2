from django.db import models

# Create your models here.

#below is for page 4
class Item(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    details = models.TextField()
    data_type = models.CharField(max_length=255)
    validation = models.CharField(max_length=255)

    def __str__(self):
        return self.name